﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RelfectPlane : MeshInfo
{
    public Vector3 m_vPlaneNormal = Vector3.up;
}
